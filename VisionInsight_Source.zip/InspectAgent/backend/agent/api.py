"""Read-only analysis HTTP boundary and lazy application-scoped SDK lifecycle."""

import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
import logging
import ipaddress
import os
from typing import Annotated
from uuid import uuid4

logger = logging.getLogger("backend.agent.api")

from fastapi import APIRouter, Depends, HTTPException, Path, Request
from google import genai
from google.genai.client import Client as GeminiSDKClient
from google.genai import types
from pydantic import ValidationError
from starlette.concurrency import run_in_threadpool

from backend.agent.schemas import AnalysisError, AnalysisErrorResponse, AnalysisResponse, DiagnosisResult
from backend.agent.service import AgentService, CORE_FIELDS, SUMMARY_TEXT
from backend.agent.errors import AgentFailure
from backend.agent.report_store import AgentReportStore, ReportStoreError, get_agent_report_store
from backend.agent.runtime_safety import (
    API_VERSION, SDK_ATTEMPTS, SAFETY_REVISION, AnalysisAdmission,
    effective_configuration, expected_configuration, verify_configuration,
)
from backend.agent.tools import INSPECTION_ID_PATTERN, InspectionTools, _valid_id
from backend.config import Settings, get_settings
from backend.storage import InspectionStorageBase, get_inspection_storage


ERROR_STATUS = {
    "INVALID_ARGUMENT": 422,
    "NOT_FOUND": 404,
    "MISSING_API_KEY": 503,
    "INVALID_MODEL_CONFIG": 503,
    "AGENT_CONFIG_CHANGED": 503,
    "AGENT_RUNTIME_CONFIG_MISMATCH": 503,
    "AGENT_ADMISSION_UNAVAILABLE": 503,
    "AGENT_BUSY": 409,
    "AGENT_REPORT_EXISTS": 409,
    "AGENT_REPORT_STORAGE_FAILED": 503,
    "PROVIDER_REQUEST_LIMIT": 502,
    "STORAGE_ERROR": 503,
    "DATA_UNAVAILABLE": 503,
    "TOOL_CAPACITY_EXCEEDED": 503,
    "GEMINI_REQUEST_FAILED": 502,
    "GEMINI_TIMEOUT": 504,
    "AGENT_TIMEOUT": 504,
    "TOOL_TIMEOUT": 504,
    "TOOL_NOT_ALLOWED": 502,
    "TOOL_ARGUMENT_INVALID": 502,
    "INSPECTION_SCOPE_MISMATCH": 502,
    "PRODUCT_SCOPE_MISMATCH": 502,
    "TOOL_CALL_LIMIT": 502,
    "TOOL_REPEAT_LIMIT": 502,
    "TOOL_ROUND_LIMIT": 502,
    "TOOL_EXECUTION_FAILED": 503,
    "TOOL_RESPONSE_INVALID": 502,
    "TOOL_DATA_TOO_LARGE": 502,
    "CONTEXT_TOO_LARGE": 502,
    "MODEL_RESPONSE_TOO_LARGE": 502,
    "INSUFFICIENT_EVIDENCE": 502,
    "MODEL_RESPONSE_INVALID": 502,
    "MODEL_RESPONSE_INCOMPLETE": 502,
    "UNEXPECTED_FUNCTION_CALL": 502,
    "FINAL_JSON_INVALID": 502,
    "RESPONSE_SCHEMA_INVALID": 502,
    "EVIDENCE_MISMATCH": 502,
    "AGENT_INTERNAL_ERROR": 500,
}


def analysis_error(code: str):
    safe_code = code if isinstance(code, str) and code in ERROR_STATUS else "AGENT_INTERNAL_ERROR"
    raise HTTPException(
        status_code=ERROR_STATUS[safe_code],
        detail=AnalysisError(error_code=safe_code).model_dump(),
    )


class AgentRuntime:
    """One lazy SDK client per application; analysis state remains request-local."""

    def __init__(self):
        self._lock = asyncio.Lock()
        self._client = None
        self._configuration = None
        self._close_timeout = 15
        self.admission = AnalysisAdmission()

    async def service(self, tools: InspectionTools, settings: Settings) -> AgentService:
        if not settings.GEMINI_API_KEY:
            return AgentService(tools, settings=settings)
        configuration = (settings.GEMINI_API_KEY, settings.AGENT_MODEL_TIMEOUT_SECONDS)
        async with self._lock:
            if self._client is not None and self._configuration != configuration:
                analysis_error("AGENT_CONFIG_CHANGED")
            if self._client is None:
                try:
                    self._client = genai.Client(
                        api_key=settings.GEMINI_API_KEY,
                        http_options=types.HttpOptions(
                            api_version=API_VERSION,
                            timeout=int(settings.AGENT_MODEL_TIMEOUT_SECONDS * 1000),
                            retry_options=types.HttpRetryOptions(attempts=SDK_ATTEMPTS),
                        ),
                    )
                except Exception as exc:
                    logger.error("Failed to initialize genai.Client: exception_class=%s", exc.__class__.__name__)
                    analysis_error("INVALID_MODEL_CONFIG")
                self._configuration = configuration
                self._close_timeout = settings.AGENT_MODEL_TIMEOUT_SECONDS
        service = AgentService(tools, settings=settings, client=self._client)
        service.report_provenance = (
            "LIVE_AGENT_ANALYSIS" if isinstance(self._client, GeminiSDKClient)
            and getattr(self._client, "analysis_mode", None) != "FAKE_TEST" else "FAKE_TEST"
        )
        return service

    async def aclose(self):
        client, self._client = self._client, None
        self._configuration = None
        if client is not None:
            try:
                await asyncio.wait_for(client.aio.aclose(), timeout=self._close_timeout)
            except Exception:
                pass
            finally:
                try:
                    client.close()
                except Exception:
                    pass


@dataclass
class AnalysisContext:
    inspection_id: str
    record: dict
    tools: InspectionTools


def get_validated_inspection_id(
    inspection_id: Annotated[str, Path(
        description="Existing server-managed inspection ID: INSP- followed by 6 to 12 digits.",
        examples=["INSP-000001"],
    )],
) -> str:
    if not _valid_id(inspection_id, INSPECTION_ID_PATTERN):
        analysis_error("INVALID_ARGUMENT")
    return inspection_id


def get_analysis_storage(inspection_id: str = Depends(get_validated_inspection_id)) -> InspectionStorageBase:
    try:
        return get_inspection_storage()
    except Exception:
        analysis_error("STORAGE_ERROR")


async def get_analysis_context(
    inspection_id: str = Depends(get_validated_inspection_id),
    storage: InspectionStorageBase = Depends(get_analysis_storage),
) -> AnalysisContext:
    tools = InspectionTools(storage)
    try:
        result = await run_in_threadpool(tools.get_inspection_result, inspection_id)
    except Exception:
        analysis_error("STORAGE_ERROR")
    if not result["ok"]:
        analysis_error(result["error"])
    return AnalysisContext(inspection_id=inspection_id, record=result["data"], tools=tools)


async def get_agent_service(
    request: Request,
    context: AnalysisContext = Depends(get_analysis_context),
    settings: Settings = Depends(get_settings),
) -> AgentService:
    runtime = getattr(request.app.state, "agent_runtime", None)
    if runtime is None:
        runtime = AgentRuntime()
        request.app.state.agent_runtime = runtime
    try:
        candidate = AgentService(context.tools, settings=settings)
        if settings.GEMINI_API_KEY:
            verify_configuration(settings, candidate.limits)
        return await runtime.service(context.tools, settings)
    except AgentFailure as failure:
        analysis_error(failure.code)
    except HTTPException:
        raise
    except Exception:
        analysis_error("AGENT_INTERNAL_ERROR")


router = APIRouter(tags=["Agent analysis"])


def require_new_report(
    context: AnalysisContext = Depends(get_analysis_context),
    store: AgentReportStore = Depends(get_agent_report_store),
):
    try:
        store.ensure_absent(context.inspection_id)
    except ReportStoreError as error:
        analysis_error(error.code)


async def analysis_admission(request: Request):
    runtime = getattr(request.app.state, "agent_runtime", None)
    if runtime is None:
        runtime = AgentRuntime()
        request.app.state.agent_runtime = runtime
    try:
        with runtime.admission.acquire():
            yield
    except AgentFailure as failure:
        analysis_error(failure.code)


@router.get("/agent/runtime-safety", include_in_schema=False)
async def runtime_safety(request: Request, settings: Settings = Depends(get_settings)):
    try:
        local_peer = request.client is not None and ipaddress.ip_address(request.client.host).is_loopback
    except ValueError:
        local_peer = False
    if not local_peer or request.url.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise HTTPException(status_code=404, detail="Not found")
    candidate = AgentService(None, settings=settings)
    configuration = effective_configuration(settings, candidate.limits)
    expected = expected_configuration(settings)
    runtime = getattr(request.app.state, "agent_runtime", None)
    return {
        "safety_revision": SAFETY_REVISION, "pid": os.getpid(),
        "effective": configuration, "expected": expected,
        "configuration_matches": configuration == expected,
        "credentials_configured": bool(settings.GEMINI_API_KEY),
        "client_initialized": runtime is not None and runtime._client is not None,
        "client_configuration_matches": runtime is None or runtime._client is None or runtime._configuration == (
            settings.GEMINI_API_KEY, settings.AGENT_MODEL_TIMEOUT_SECONDS,
        ),
        "worker_count": "UNKNOWN", "protection": "OS_FILE_LOCK_SAME_CHECKOUT_AND_TEMP_NAMESPACE",
        "public_deployment_supported": False,
    }


@router.post(
    "/analyze/{inspection_id}", response_model=AnalysisResponse,
    dependencies=[Depends(analysis_admission), Depends(require_new_report)],
    summary="Analyze an existing inspection without changing its verdict",
    description=(
        "Post-inspection diagnosis using stored results and logs; publishes a new immutable Agent report. "
        "Requires an existing inspection, including FAILED inspections. Does not create an inspection, "
        "reload an image or run PatchCore. Gemini configuration is required only for analysis requests."
    ),
    responses={status: {"model": AnalysisErrorResponse, "description": description} for status, description in {
        404: "Inspection not found", 409: "Another analysis is in progress", 422: "Invalid inspection identifier",
        500: "Unexpected internal failure", 502: "Agent service or validated output failure",
        503: "Agent configuration, storage or tool unavailable", 504: "Analysis or dependency timeout",
    }.items()},
)
async def analyze_inspection(
    context: AnalysisContext = Depends(get_analysis_context),
    service: AgentService = Depends(get_agent_service),
    store: AgentReportStore = Depends(get_agent_report_store),
) -> AnalysisResponse:
    try:
        raw = await service.analyze(context.inspection_id)
        result = DiagnosisResult.model_validate(raw.model_dump(mode="json") if isinstance(raw, DiagnosisResult) else raw)
    except ValidationError:
        analysis_error("RESPONSE_SCHEMA_INVALID")
    except TimeoutError:
        analysis_error("AGENT_TIMEOUT")
    except Exception:
        analysis_error("AGENT_INTERNAL_ERROR")
    if result.analysis_status != "COMPLETED":
        logger.warning(
            "Agent analysis completed with failure: inspection_id=%s, error_code=%s, model_name=%s",
            context.inspection_id, result.error_code, result.model_name,
        )
        analysis_error(result.error_code)
    if result.error_code is not None or result.inspection_id != context.inspection_id:
        analysis_error("EVIDENCE_MISMATCH")
    snapshot_fields = (*CORE_FIELDS, "anomaly_score", "decision_threshold")
    if result.inspection_snapshot is None or any(
        result.inspection_snapshot.get(name) != context.record.get(name) for name in snapshot_fields
    ):
        analysis_error("EVIDENCE_MISMATCH")
    summary_code = {
        "OK": "NORMAL_MODEL_RESULT", "NG": "PRODUCT_ANOMALY", "REINSPECT": "REINSPECTION_REQUIRED", "ERROR": "INSPECTION_FAILED",
    }.get(context.record["final_result"], "INSUFFICIENT_DATA")
    if result.overall_summary != SUMMARY_TEXT[summary_code]:
        analysis_error("EVIDENCE_MISMATCH")
    response_data = result.model_dump()
    response_data["inspection_snapshot"] = {name: context.record.get(name) for name in snapshot_fields}
    analysis_resp = AnalysisResponse(
        **response_data, analysis_id=f"ANALYSIS-{uuid4().hex}",
        inspection_result=context.record["result"], final_result=context.record["final_result"],
        final_reason_code=context.record["final_reason_code"], timestamp=datetime.now(timezone.utc).isoformat(),
        provenance=getattr(service, "report_provenance", "FAKE_TEST"),
    )
    try:
        await run_in_threadpool(store.save, analysis_resp.model_dump(mode="json"))
    except ReportStoreError as error:
        analysis_error(error.code)
    return analysis_resp
